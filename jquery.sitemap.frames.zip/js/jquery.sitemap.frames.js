(function( $ ) {
 
	$.fn.slider = function( options ) {
		
		var el=this;
	
        var settings = $.extend({           
            sitemap: "/sitemap.xml",           
        }, options );
       
        $.get(settings.sitemap,function(data){
        	
    		var links = [];	
    		 
    		 $(data).find('loc').each(function(index){			 
    			 links[index]=$($(this)).text();			 
    		 });
    		 
    	var length=links.length;
    	
    	var i=0;
    	
    	$(el).wrap('<div class="slider-wrapper"><div class="slider-viewport"></div><div class="slider-controls slider-has-controls-direction"><div class="slider-controls-direction"><a class="slider-prev">Prev</a><a class="slider-next">Next</a></div></div></div>');
    	$(el).append('<li class="item-slider-active"><iframe class="screenframe" src="'+links[i]+'"></iframe></li>');    

    $('.slider-next').click(function() {		
    	i=i+1;	
    	if(i<length){
    	$(el).empty();		
    	$(el).append('<li class="item-slider-active"><iframe class="screenframe" src="'+links[i]+'"></iframe></li>');
    	}else{
    		i=length-1;
    		$(el).empty();		
    		$(el).append('<li class="item-slider-active"><iframe class="screenframe" src="'+links[i]+'"></iframe></li>');
    	}
    });

    $('.slider-prev').click(function() {		
    	i=i-1;
    	if(i>0){
    	$(el).empty();		
    	$(el).append('<li class="item-slider-active"><iframe class="screenframe" src="'+links[i]+'"></iframe></li>');
    	}else{
    		i=0;
    		$(el).empty();		
    		$(el).append('<li class="item-slider-active"><iframe class="screenframe" src="'+links[i]+'"></iframe></li>');
    	}
    });

    	});
        
        return this;
 
    };
}( jQuery ));